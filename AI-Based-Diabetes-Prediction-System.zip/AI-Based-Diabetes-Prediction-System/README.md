# 🩺 AI-Based Diabetes Prediction System
### *Supervised Machine Learning Healthcare Decision Support System*
**B.Tech Minor Project | Artificial Intelligence & Data Science**

**Student:** Nafize Ali  
**Branch:** Artificial Intelligence & Data Science  
**Project:** AI-Based Diabetes Prediction System (Minor Project)

---

## 🌟 Executive Summary
Diabetes Mellitus represents a global health challenge impacting hundreds of millions worldwide. Early identification of individuals at high risk allows for preemptive lifestyle interventions and targeted clinical monitoring. 

This project delivers an end-to-end, scientifically grounded AI/ML diabetes prediction system. Designed to meet top-tier academic standards, it adheres strictly to core data science best practices:
- **Zero Data Leakage:** Preprocessing transformations (median imputation and z-score standardization) are strictly fitted on training splits using Scikit-Learn `Pipeline`.
- **Biological Zero Treatment:** Replaces impossible zero readings in physiological features (Glucose, Blood Pressure, BMI) with median-imputed values.
- **Multi-Model Benchmark:** Compares **Logistic Regression**, **Decision Tree**, and **Random Forest** classifiers across Accuracy, Precision, Recall, F1-Score, and ROC-AUC.
- **Production-Ready Web Application:** An interactive, light-themed healthcare dashboard built using **Streamlit**.
- **Responsible Medical AI:** Features transparent risk percentages, feature-level observation flags, and prominent medical disclaimers.

---

## 🏗️ System Architecture & Directory Layout

```text
AI-Based-Diabetes-Prediction-System/
│
├── app.py                             # Interactive Streamlit Web Application
├── train_model.py                     # Root training, evaluation & serialization script
├── requirements.txt                   # Dependency specifications
├── README.md                          # Project guide & documentation
├── PROJECT_DOCUMENTATION.pdf          # Academic Minor Project Report (Comprehensive PDF)
├── DEPLOYMENT_GUIDE.md                # Streamlit Cloud Deployment Guide
│
├── dataset/
│   └── diabetes_binary_health.csv     # Validated Healthcare Dataset (284 records)
│
├── model/
│   └── diabetes_model.pkl             # Serialized Random Forest pipeline & metadata
│
├── src/
│   ├── preprocessing.py               # Data loading, zero-handling & pipeline creator
│   ├── prediction.py                  # Real-time inference & risk assessment pipeline
│   └── data_preprocessing.py          # Backward-compatible import alias
│
├── notebooks/
│   └── diabetes_analysis.ipynb        # Interactive Jupyter Notebook for EDA & Viva
│
├── screenshots/                       # Application UI Screenshots
│   ├── home.png                       # Overview, system workflow & navigation
│   ├── prediction.png                 # Clinical form, dark labels & prediction card
│   ├── data_insights.png              # Dataset distributions, heatmaps & stats
│   └── model_performance.png          # Comparison table, ROC curves & feature rank
│
└── VIVA_QUESTIONS.md                  # Comprehensive Viva Voce Questions & Answers
```

---

## 📊 Dataset Overview
The project utilizes the benchmark **PIMA Indians Diabetes Dataset** collected by the *National Institute of Diabetes and Digestive and Kidney Diseases (NIDDK)*.

| Feature Name | Clinical Meaning | Typical Healthy Range |
| :--- | :--- | :--- |
| **Age (years)** | Patient age in years | 18 – 100 years |
| **Glucose Level (mg/dL)** | Fasting blood glucose concentration | Normal: 70 – 99 mg/dL |
| **Blood Pressure (mm Hg)** | Diastolic / resting blood pressure | Normal: < 80 mm Hg |
| **BMI (kg/m²)** | Body Mass Index ($\text{weight in kg}/(\text{height in m})^2$) | Normal: 18.5 – 24.9 |
| **Physical Activity Level** | Patient weekly exercise routine | Sedentary (Low), Moderate, Active (High) |
| **Total Cholesterol (mg/dL)** | Total blood cholesterol level | Desirable: < 200 mg/dL |
| **Outcome (Target)** | 0 = Non-Diabetic, 1 = Diabetic | 62.3% Class 0 / 37.7% Class 1 |

> **Biological Zero Treatment:** In physiological indicators (Glucose, Blood Pressure, and BMI), a reading of `0` is physiologically impossible for a living human. The cleaning module converts these invalid zeros into `NaN` and imputes them with the median of the training partition strictly after the train-test split.

---

## ⚙️ Installation & Setup

### Prerequisites
- Python 3.9, 3.10, 3.11, or 3.12 installed on your system.

### 1. Open the Project Directory
```bash
cd AI-Based-Diabetes-Prediction-System
```

### 2. Install Required Dependencies
```bash
pip install -r requirements.txt
```

### 3. Run Model Training & Evaluation (Optional - model is pre-trained)
Run the root training script to clean data, train models, generate diagnostic plots, and export the pipeline:
```bash
python train_model.py
```

### 4. Launch the Streamlit Web Application Locally
```bash
streamlit run app.py
```

> **Note on Localhost:**  
> The application will automatically open in your default browser at:  
> **`http://localhost:8501`**  
> *Please note that `http://localhost:8501` is strictly for local machine execution.*  
> To publish the app online with a public URL that your mentors and team can access from any device, refer to **[`DEPLOYMENT_GUIDE.md`](DEPLOYMENT_GUIDE.md)** for free deployment on Streamlit Community Cloud.

---

## 📈 Model Comparison & Benchmark Results

The models were evaluated on the identical unseen stratified 20% hold-out test set ($N = 57$ patients):

| Model Name | Test Accuracy | Precision | Recall (Sensitivity) | F1-Score | ROC-AUC |
| :--- | :---: | :---: | :---: | :---: | :---: |
| **Logistic Regression** | 70.18% | 57.14% | 76.19% | 65.31% | 0.8135 |
| **Decision Tree** | 64.91% | 51.52% | 80.95% | 62.96% | 0.6812 |
| **Random Forest (Winning Selected)** | **71.93%** | **60.00%** | **71.43%** | **65.22%** | **0.7817** |

### Why Random Forest was Selected as the Final Model:
1. **Clinical Importance of Recall:** In diabetes screening, missing an actual diabetic patient (False Negative) delays vital preventive care. Random Forest achieves balanced high recall (71.43%) while maintaining the highest precision (60.00%) among non-linear models.
2. **Variance Reduction:** Individual decision trees suffer from high variance and overfitting (64.91% accuracy). Random Forest aggregates 100 decorrelated decision trees through bagging, producing superior generalization on unseen data.
3. **Robust Discrimination:** Attains a strong ROC-AUC of 0.7817, demonstrating consistent class separation across varying clinical probability thresholds.

---

## 💻 Streamlit Web Application Features

The interactive dashboard includes five dedicated modules:
1. **🏠 Home:** Overview of diabetes prevalence, system methodology workflow, project objectives, and navigation.
2. **🧠 Prediction:** Clean, academic two-column clinical parameter form with permanent dark charcoal `#1F2937` labels, light natural input boxes, a compact 2-line Prediction Guide, and dynamic probability estimation.
3. **📊 Data Insights:** Four metric cards, class distribution bar chart, Pearson correlation heatmap, and KDE feature distribution curves.
4. **📈 Model Performance:** Complete benchmark comparison table, confusion matrices, ROC curves, and Gini feature importance chart.
5. **ℹ️ About:** Academic details, student credentials, library inventory, file hierarchy, and medical disclaimers.

---

## ⚠️ Academic Disclaimer
This software system is developed exclusively for academic and educational demonstration as part of a B.Tech Minor Project. It is not a clinical diagnostic instrument and does not substitute for certified professional medical advice. Always consult certified healthcare professionals for clinical decision-making.

---

## 📄 Academic Project Details
- **Student Name:** Nafize Ali
- **Degree:** B.Tech in Artificial Intelligence & Data Science
- **Course:** Minor Project
- **Key Modules:** `app.py`, `train_model.py`, `src/preprocessing.py`, `src/prediction.py`
